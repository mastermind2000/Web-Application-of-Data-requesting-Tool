<!DOCTYPE html>
<html>
<br>
<br>
<br>
<form action=FetchData.php?Pre='.$Pre.'&Pos='.$Pos.' method="get" target="_blank">
  Pre time: <input type="text", name="Pre" class="click"><br>
  Pos time: <input type="text", name="Pos" class="click"><br>
  <button name="Submit" class="click">Submit</button>
</form>

<?php

  if(isset($_GET['Submit']))
  {
    $Pre=$_GET['Pre'];
    $Pos=$_GET['Pos'];
    echo $Pre;
    echo $Pos;
  }

?>
<?php include 'decorate.html' ?>
</html>
